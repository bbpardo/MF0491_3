## Documentacion del contenido

En el ejercicio realizado disponemos de un index.html con 2 elemento para trabajar en los cuales se buscalo siguiente:

- Cuando se pulse un click cambie un parrafo
- Ambos elemento se encuentre a un tercio y dos tercis repectivamente
- Ningun error en consola

Lo elemento con los que se va a trabajar son los siguiente:

```
<p id="textEdit">Has pulsado el boton 0 veces</p>
<button id="buttonClick">Pulsar</button>
```

Se creo un varable para almacenar los clicks realizados:

```
 let clicks = 0
```

Un vez con la variable creada ya podemos crear un evento que al hacer click sume 1 al dicha variable y cambie el texto del parrafo monstrado anteriormente :

```
document.querySelector("#buttonClick").addEventListener("click", ()=>{
    clicks = clicks + 1;
    document.querySelector("#textEdit").innerText= "Has pulsado el boton "+clicks+" veces" ;

})
```

El ultimo paso es modificar el aspecto visual, se realizo a traves de clases reutilizables como os muestro en el siguiente ejemplo:

```
#CSS
.font-size-xx-large {
	font-size: xx-large;
}
#HTML
class="f-grow-1 font-size-xx-large justify-content-space-between"
```

De dicha manera aplicamos varias clases a un elemento haciendo cambios en su comportamiento y aspecto con intencion de que dichas clases queden almacenadas y se puedan volver a usar en otro elemento sin afectarse entre si.
