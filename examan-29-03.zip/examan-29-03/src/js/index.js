/**
 * Variable para registrar los clicks realizados
 */
let clicks = 0
/**
 * Selector del boton con evento de click para realizar la suma a la variable clicks y aztualizar los datos mostrados en el parrafo.
 */
document.querySelector("#buttonClick").addEventListener("click", ()=>{
    clicks = clicks + 1;
    document.querySelector("#textEdit").innerText= "Has pulsado el boton "+clicks+" veces" ;

})
